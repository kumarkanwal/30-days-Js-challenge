// Selected All buttons and container
const buttons = document.querySelectorAll('button');
const buttonDiv = document.getElementById('buttons'); 
const container = document.querySelector('.container');
const colorPicker = document.getElementById("colorPicker");
const saveBtn = document.getElementById('save');
const randomColorCode = document.getElementById('colorCode');
const colorNameInput = document.getElementById('colorName');
const form = document.getElementById('form');







// ------------------ accessing local storage ----------------------

// access data from the local storage
container.style.backgroundColor = localStorage.getItem("backgroundColor") || "wheat";
// setting local storage value to the input
colorPicker.value = localStorage.getItem("backgroundColor") || "wheat";


// ----------------------- random color input code-----------------------
//  fetching real time color change code through event listener
colorPicker.addEventListener('input', ()=>{
const RandomColor = colorPicker.value;

// adding color code into the input 
randomColorCode.value = RandomColor;

  // adding background color to the container
  container.style.backgroundColor = RandomColor;

  // saving data to the local storage
  localStorage.setItem("backgroundColor",RandomColor);
} )


// --------------- color buttons code ------------------
// foreach on all buttons
buttons.forEach(button=> {

    button.addEventListener('click', () =>{
        // accessing element css
        let buttonStyle = getComputedStyle(button);

        // adding background color to the container
        let buttonBackgroundColor = buttonStyle.backgroundColor;
        container.style.backgroundColor = buttonBackgroundColor;

        // saving data to the local storage
        localStorage.setItem("backgroundColor",buttonBackgroundColor);


    })

    button.setAttribute('draggable', 'true');

})

// ---------------------- Drag and drop feature ------------

document.addEventListener('DOMContentLoaded',(event)=>{
  let dragged;


 buttons.forEach(button => {
    button.addEventListener('dragstart',function(e){
      dragged = e.target
      e.target.style.opacity = 0.5;

    })


    button.addEventListener('dragend',function(e){
      e.target.style.opacity = "";

    })
  })


  container.addEventListener('dragover' , function(e){
    e.preventDefault();
  })
})



// ---------------------- save and add a new button------------

// form.addEventListener('submit', (e)=>{

//   // prevent default event listener
//   e.preventDefault();

//   // accesing color name and code
//  let colorName = colorNameInput.value;
//  let colorCode = randomColorCode.value;

//  // creating new element
//  let newBtn = document.createElement('button');
//  newBtn.innerText = colorName;
//  newBtn.style.backgroundColor = colorCode;

//  buttonDiv.appendChild(newBtn);  
// })


