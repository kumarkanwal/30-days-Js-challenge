def number_calculations(number):
    # Write your code for task 1 here

    #number divided by 5
    divided = number/5;
    print(divided)
    
    # if number is greater than 100
    is_greater_than_100 = number > 100;
    print(is_greater_than_100)

    # reminder when divided by 9
    remainder = number % 9;
    print(remainder)

    #checking if the number is even
    is_even = number % 2 == 0
    print(is_even)

    # Result of the formula
    formula = (5 - number)+(1.5* number) / 3.0
    print(formula)


number_calculations(44)


def restaurant_waiter():
    #write your code for task 2 here

    # asking customer name
    name = input("What is your name?")
    print(f"Hello {name}, welcome to the restaurant!")

    # asking food want to order
    food = input("What food you like to order?")
    print(f"Customer {name} wants {food}.")

    # Number of plates customer wants to order
    no_of_plates = int(input("How many plates you want to order."))
    print(f"Requests for {no_of_plates} orders of {food} by customer {name}.")

    # Amount customer willing to pay for each plate
    amount = int(input('How much you are willing to pay for each plate of food?'))
    print(f"Total bill for customer {name} is {amount * no_of_plates} dollars.")




restaurant_waiter()




def rps_result(p1_move, p2_move):
    # Write your code for task 3 here 

    player1 = (p1_move).lower()
    player2 = (p2_move).lower()

#  possible moves 
    # similar
    # rock paper
    # paper rock
    # rock scissors
    # scissors rock 
    #  paper scissors
    # scissors paper 


    if player1 == player2:
        # when both choose same
        print("Draw")
        # when player1 choose Rock and player2 choose Paper
    elif player1 == "rock" and player2 == "paper":
        print("Player2 Win")

        # when player1 choose Paper and player2 choose Rock
    elif player1 == "paper" and player2 == "rock":
        print("Player1 Win")
    
       # when player1 choose Scissors and player2 chooses Rock
    elif player1 == "scissors" and player2 == "rock":
        print("Player2 Win")
    
       # when player1 choose Rock and player2 chooses Scissors
    elif player1 == "rock" and player2 == "scissors":
        print("Player1 Win")


       # when player1 choose Scissors and player2 chooses Paper
    elif player1 == "scissors" and player2 == "paper":
        print("Player1 Win")

       # when player1 choose Paper and player2 chooses Scissors
    elif player1 == "paper" and player2 == "scissors":
        print("Player2 Win")


rps_result("paper" , "rock")




def population_prediction(prey,predator,years):
    #Write your code for task 4 here
    current_prey = prey
    current_predator = predator



    for year in range(years):
 
        # Expected Increase in population each year
        expected_prey_population = current_prey + (0.1 * current_prey) - (0.002 * current_prey * current_predator)
        expected_predator_population = current_predator +  (0.0025 * current_prey * current_predator) - (0.2 * current_predator)

        # updating cuurent population after every year increase
        current_predator = expected_predator_population
        current_prey = expected_prey_population


    print(expected_prey_population)
    print(expected_predator_population)


population_prediction(100,50,85)


